package io.github.eutera.trackline.provider.spotify.catalog.authorization

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.core.net.toUri
import io.github.eutera.trackline.provider.spotify.SpotifyConfiguration
import java.lang.ref.WeakReference

/** Opens the provider's OAuth page and returns the matching app link as an activity result. */
class SpotifyCatalogAuthorizationActivity : Activity() {
    private var leftForBrowser = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        leftForBrowser = savedInstanceState?.getBoolean(LEFT_FOR_BROWSER) == true
        setResult(RESULT_CANCELED)
        val url = authorizationUrl()
        if (url == null) {
            finish()
            return
        }
        activeActivity = WeakReference(this)
        if (savedInstanceState == null) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, url))
            } catch (_: ActivityNotFoundException) {
                setResult(RESULT_FIRST_USER)
                finish()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) leftForBrowser = true
    }

    override fun onResume() {
        super.onResume()
        if (leftForBrowser && !isFinishing) finish()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putBoolean(LEFT_FOR_BROWSER, leftForBrowser)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (activeActivity?.get() === this) activeActivity = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val callback = intent.data ?: return
        if (accepts(callback)) {
            setResult(RESULT_OK, Intent().setData(callback))
            finish()
        }
    }

    private fun authorizationUrl(): Uri? = intent.data

    private fun accepts(callback: Uri): Boolean {
        val state = authorizationUrl()?.getQueryParameter("state") ?: return false
        val redirect = SpotifyConfiguration.fromManifest(this).catalogRedirect.toUri()
        return matchesSpotifyCatalogRedirect(callback, redirect) &&
            callback.getQueryParameters("state") == listOf(state)
    }

    internal companion object {
        private const val LEFT_FOR_BROWSER = "left_for_browser"
        private var activeActivity: WeakReference<SpotifyCatalogAuthorizationActivity>? = null

        fun request(context: Context, url: Uri) =
            Intent(context, SpotifyCatalogAuthorizationActivity::class.java).setData(url)

        fun resumeWith(callback: Uri) {
            val activity = activeActivity?.get() ?: return
            if (activity.isFinishing || !activity.accepts(callback)) return
            // CLEAR_TOP must find the original activity in its own task.
            activity.startActivity(
                request(activity, callback)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        }
    }
}
