package io.github.eutera.trackline.provider.spotify.catalog

import android.util.Log
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.github.eutera.trackline.provider.spotify.spotifyTrace
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import org.json.JSONException
import org.json.JSONObject

internal class SpotifyHttpClient(
    private val transport: ((String, Map<String, String>?, String?) -> JSONObject)? = null
) {
    fun request(
        url: String,
        form: Map<String, String>? = null,
        bearer: String? = null,
    ): JSONObject {
        val operation = if (form == null) "catalog" else "token"
        return try {
            transport?.invoke(url, form, bearer) ?: requestOverHttp(url, form, bearer, operation)
        } catch (_: JSONException) {
            spotifyTrace("http operation=$operation failed code=UNAVAILABLE", Log.WARN)
            throw ProviderException(ProviderError.UNAVAILABLE)
        } catch (_: IOException) {
            spotifyTrace("http operation=$operation failed code=OFFLINE", Log.WARN)
            throw ProviderException(ProviderError.OFFLINE)
        }
    }

    private fun requestOverHttp(
        url: String,
        form: Map<String, String>?,
        bearer: String?,
        operation: String,
    ): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 15_000
            connection.instanceFollowRedirects = false
            bearer?.let { connection.setRequestProperty("Authorization", "Bearer $it") }
            if (form != null) {
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                connection.outputStream.use { output ->
                    output.write(
                        form.entries
                            .joinToString("&") { encode(it.key) + "=" + encode(it.value) }
                            .toByteArray(Charsets.UTF_8)
                    )
                }
            }
            val status = connection.responseCode
            if (status !in 200..299) {
                spotifyTrace("http operation=$operation status=$status", Log.WARN)
                throw ProviderException(
                    when (status) {
                        401,
                        400 -> {
                            ProviderError.AUTHORIZATION
                        }
                        403 -> ProviderError.PERMISSION
                        404 -> ProviderError.UNAVAILABLE
                        429 -> ProviderError.RATE_LIMIT
                        else -> ProviderError.TEMPORARY
                    },
                    if (status == 429) {
                        connection
                            .getHeaderField("Retry-After")
                            ?.toLongOrNull()
                            ?.coerceIn(0, 86400)
                            ?.times(1000)
                    } else {
                        null
                    },
                )
            }
            return connection.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        } finally {
            connection.disconnect()
        }
    }

    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8")
}
