package io.github.eutera.trackline.provider.spotify.catalog.authorization

import android.net.Uri
import android.os.SystemClock
import android.util.Base64
import android.util.Log
import androidx.core.net.toUri
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.github.eutera.trackline.provider.spotify.catalog.SpotifyHttpClient
import io.github.eutera.trackline.provider.spotify.spotifyClientConfigured
import io.github.eutera.trackline.provider.spotify.spotifyTrace
import java.security.MessageDigest
import java.security.SecureRandom
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal class SpotifyAuthorizationRepository(
    private val clientId: String,
    private val redirect: String,
    private val http: SpotifyHttpClient,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val clock: () -> Long = SystemClock::elapsedRealtime,
) {
    private data class Transaction(val state: String, val verifier: String, val created: Long)

    private data class Credentials(val access: String, val refresh: String?, val expires: Long)

    private val sessionLock = Any()
    private val refreshMutex = Mutex()
    private var pending: Transaction? = null
    private var credentials: Credentials? = null
    private var version = 0
    private val mutableAuthorized = MutableStateFlow(false)
    val authorized = mutableAuthorized.asStateFlow()
    internal val generation
        get() = synchronized(sessionLock) { version }

    val configured
        get() =
            spotifyClientConfigured(clientId) &&
                redirect.toUri().let {
                    it.scheme == "https" &&
                        !it.host.isNullOrBlank() &&
                        it.host != "callback.invalid" &&
                        it.userInfo == null &&
                        it.port == -1 &&
                        it.query == null &&
                        it.fragment == null
                }

    fun authorize(): Uri {
        check(configured)
        spotifyTrace("catalog authorization started")
        val transaction = Transaction(random(), random(), clock())
        synchronized(sessionLock) {
            clearSession()
            pending = transaction
            mutableAuthorized.value = false
        }
        val digest =
            MessageDigest.getInstance("SHA-256")
                .digest(transaction.verifier.toByteArray(Charsets.US_ASCII))
        return "https://accounts.spotify.com/authorize"
            .toUri()
            .buildUpon()
            .appendQueryParameter("client_id", clientId)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", redirect)
            .appendQueryParameter("state", transaction.state)
            .appendQueryParameter("code_challenge_method", "S256")
            .appendQueryParameter("code_challenge", Base64.encodeToString(digest, PKCE_FLAGS))
            .appendQueryParameter("scope", "playlist-read-private playlist-read-collaborative")
            .build()
    }

    suspend fun callback(uri: Uri): Boolean {
        if (!matchesSpotifyCatalogRedirect(uri, redirect.toUri())) {
            spotifyTrace("catalog authorization rejected code=CALLBACK_MISMATCH", Log.WARN)
            return false
        }
        val (transaction, currentVersion) =
            synchronized(sessionLock) {
                val transaction = pending ?: return false
                if (uri.getQueryParameters("state") != listOf(transaction.state)) {
                    spotifyTrace("catalog authorization rejected code=STATE_MISMATCH", Log.WARN)
                    return false
                }
                pending = null
                transaction to version
            }
        val expired = clock() - transaction.created !in 0..600_000L
        if (
            expired ||
                uri.getQueryParameter("error") != null ||
                uri.getQueryParameters("code").size != 1
        ) {
            val code = if (expired) "EXPIRED" else "INVALID_OR_DENIED"
            spotifyTrace("catalog authorization rejected code=$code", Log.WARN)
            reject(currentVersion)
            return false
        }
        return try {
            val tokens =
                requestTokens(
                    mapOf(
                        "grant_type" to "authorization_code",
                        "code" to uri.getQueryParameter("code").orEmpty(),
                        "redirect_uri" to redirect,
                        "code_verifier" to transaction.verifier,
                    )
                )
            (applyTokens(currentVersion, tokens) != null).also { authorized ->
                if (authorized) spotifyTrace("catalog authorization completed")
            }
        } catch (error: CancellationException) {
            reject(currentVersion)
            throw error
        } catch (error: Exception) {
            val code = (error as? ProviderException)?.category?.name ?: "INVALID_RESPONSE"
            spotifyTrace("catalog authorization failed code=$code", Log.WARN)
            reject(currentVersion)
            false
        }
    }

    internal suspend fun token(rejected: String? = null): String =
        refreshMutex.withLock {
            val cached =
                synchronized(sessionLock) {
                    credentials?.takeIf { it.access != rejected && clock() < it.expires }?.access
                }
            if (cached != null) return@withLock cached
            val (refresh, currentVersion) =
                synchronized(sessionLock) {
                    val refresh =
                        credentials?.refresh ?: throw ProviderException(ProviderError.AUTHORIZATION)
                    refresh to version
                }
            try {
                spotifyTrace("catalog token refresh requested")
                val tokens =
                    requestTokens(
                        mapOf("grant_type" to "refresh_token", "refresh_token" to refresh)
                    )
                applyTokens(currentVersion, tokens)
                    ?: throw ProviderException(ProviderError.AUTHORIZATION)
            } catch (error: CancellationException) {
                throw error
            } catch (error: Exception) {
                val failure =
                    error as? ProviderException ?: ProviderException(ProviderError.UNAVAILABLE)
                spotifyTrace("catalog token refresh failed code=${failure.category}", Log.WARN)
                if (failure.category == ProviderError.AUTHORIZATION) reject(currentVersion)
                throw failure
            }
        }

    private suspend fun requestTokens(form: Map<String, String>) =
        withContext(dispatcher) {
            http.request(
                "https://accounts.spotify.com/api/token",
                form = form + ("client_id" to clientId),
            )
        }

    private fun applyTokens(expectedVersion: Int, json: JSONObject): String? {
        val access = json.getString("access_token").also { require(it.isNotBlank()) }
        val refresh = json.optString("refresh_token").takeIf(String::isNotBlank)
        val expires = clock() + json.optLong("expires_in", 3600) * 1_000 - 30_000
        return synchronized(sessionLock) {
            if (version != expectedVersion) return@synchronized null
            credentials = Credentials(access, refresh ?: credentials?.refresh, expires)
            mutableAuthorized.value = true
            access
        }
    }

    fun disconnect() =
        synchronized(sessionLock) {
            clearSession()
            mutableAuthorized.value = false
        }

    internal fun reject(expectedVersion: Int) =
        synchronized(sessionLock) {
            if (version == expectedVersion) {
                clearSession()
                mutableAuthorized.value = false
            }
        }

    private fun clearSession() {
        ++version
        credentials = null
        pending = null
    }

    private fun random() =
        ByteArray(32)
            .also { SecureRandom().nextBytes(it) }
            .let { Base64.encodeToString(it, PKCE_FLAGS) }

    private companion object {
        const val PKCE_FLAGS = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
    }
}
