package io.github.eutera.trackline.provider.spotify.playback.authorization

import android.app.Activity
import android.content.Context
import android.content.Intent
import io.github.eutera.trackline.provider.api.ProviderAuthorization
import io.github.eutera.trackline.provider.spotify.SpotifyConfiguration
import io.github.eutera.trackline.provider.spotify.spotifyClientConfigured

internal class SpotifyPlaybackAuthorization(
    private val context: Context,
    private val configuration: SpotifyConfiguration,
) : ProviderAuthorization {
    override val configured =
        spotifyClientConfigured(configuration.clientId) &&
            configuration.appRemoteRedirect.isNotBlank()

    override fun createIntent() = Intent(context, SpotifyPlaybackAuthorizationActivity::class.java)

    override suspend fun complete(resultCode: Int, data: Intent?) = resultCode == Activity.RESULT_OK
}
