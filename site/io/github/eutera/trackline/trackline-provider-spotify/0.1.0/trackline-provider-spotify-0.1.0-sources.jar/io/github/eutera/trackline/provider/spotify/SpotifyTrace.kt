package io.github.eutera.trackline.provider.spotify

import android.util.Log

/** Log stages and typed results. SDK payloads and exception messages can contain private data. */
internal fun spotifyTrace(message: String, priority: Int = Log.DEBUG) {
    if (BuildConfig.DEBUG || priority >= Log.WARN)
        Log.println(priority, "TracklineSpotify", message)
}
