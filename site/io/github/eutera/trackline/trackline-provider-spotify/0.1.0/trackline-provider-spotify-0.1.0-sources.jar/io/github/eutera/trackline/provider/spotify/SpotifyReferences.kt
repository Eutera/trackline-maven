package io.github.eutera.trackline.provider.spotify

import io.github.eutera.trackline.provider.api.TrackRef

private val ClientIdPattern = Regex("[a-fA-F0-9]{32}")
private val TrackIdPattern = Regex("[A-Za-z0-9]{22}")

internal fun spotifyClientConfigured(clientId: String) = ClientIdPattern.matches(clientId)

internal object SpotifyTrackReferences {
    fun accepts(reference: TrackRef) =
        reference.provider == "spotify" && TrackIdPattern.matches(reference.id)

    fun fromId(id: String) = TrackRef("spotify", id).takeIf(::accepts)

    fun fromUri(uri: String): TrackRef? {
        val prefix = "spotify:track:"
        return if (uri.startsWith(prefix)) fromId(uri.removePrefix(prefix)) else null
    }

    fun toUri(reference: TrackRef) =
        if (accepts(reference)) "spotify:track:${reference.id}" else null
}
