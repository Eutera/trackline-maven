package io.github.eutera.trackline.provider.spotify.catalog.authorization

import android.app.Activity
import android.content.Context
import android.content.Intent
import io.github.eutera.trackline.provider.api.catalog.CatalogAuthorization

internal class SpotifyCatalogAuthorization(
    private val context: Context,
    private val repository: SpotifyAuthorizationRepository,
) : CatalogAuthorization {
    override val authorized = repository.authorized
    override val configured
        get() = repository.configured

    override fun createIntent(): Intent =
        SpotifyCatalogAuthorizationActivity.request(context, repository.authorize())

    override suspend fun complete(resultCode: Int, data: Intent?): Boolean {
        val callback = data?.data
        if (resultCode == Activity.RESULT_OK && callback != null) {
            return repository.callback(callback)
        }
        repository.disconnect()
        return false
    }

    override fun disconnect() = repository.disconnect()
}
