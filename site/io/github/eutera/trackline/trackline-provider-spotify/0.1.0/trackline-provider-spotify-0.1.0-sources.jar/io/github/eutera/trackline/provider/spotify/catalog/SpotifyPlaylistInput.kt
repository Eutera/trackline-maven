package io.github.eutera.trackline.provider.spotify.catalog

internal object SpotifyPlaylistInput {
    private val directReference = Regex("""(?:spotify:playlist:)?([A-Za-z0-9]{22})""")

    // Find a real Spotify host in shared prose/Markdown, then retain only the complete ID.
    // Host and ID boundaries prevent lookalike hosts and truncating a longer identifier.
    private val sharedLink =
        Regex(
            """(?i:(?:(?<![A-Za-z0-9+.-])https://|(?<![A-Za-z0-9_./:@%?=&+-]))open\.spotify\.com/playlist/)([A-Za-z0-9]{22})(?=$|[\s?#)\]}>.,!;:'"])"""
        )

    fun spotifyId(input: String): String? =
        directReference.matchEntire(input.trim())?.groupValues?.get(1)
            ?: sharedLink.find(input)?.groupValues?.get(1)
}
