package io.github.eutera.trackline.provider.spotify

import android.content.Context
import androidx.core.net.toUri
import io.github.eutera.trackline.provider.api.MusicCredits
import io.github.eutera.trackline.provider.api.MusicProvider
import io.github.eutera.trackline.provider.api.ProviderAuthorization
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.catalog.CatalogAuthorization
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import io.github.eutera.trackline.provider.spotify.catalog.SpotifyApiClient
import io.github.eutera.trackline.provider.spotify.catalog.SpotifyCatalogRepository
import io.github.eutera.trackline.provider.spotify.catalog.SpotifyHttpClient
import io.github.eutera.trackline.provider.spotify.catalog.authorization.SpotifyAuthorizationRepository
import io.github.eutera.trackline.provider.spotify.catalog.authorization.SpotifyCatalogAuthorization
import io.github.eutera.trackline.provider.spotify.playback.SpotifyPlaybackGateway
import io.github.eutera.trackline.provider.spotify.playback.authorization.SpotifyPlaybackAuthorization
import kotlinx.coroutines.CoroutineScope

class SpotifyProvider
internal constructor(
    context: Context,
    private val configuration: SpotifyConfiguration,
    http: SpotifyHttpClient,
) : MusicProvider {
    constructor(
        context: Context
    ) : this(context, SpotifyConfiguration.fromManifest(context), SpotifyHttpClient())

    private val applicationContext = context.applicationContext

    override val id = "spotify"
    override val displayName = "Spotify"
    override val musicCredits =
        MusicCredits(emptyList(), applicationContext.getString(R.string.spotify_music_credits))
    override val installationUri =
        "https://play.google.com/store/apps/details?id=com.spotify.music".toUri()
    private val authorizationRepository =
        SpotifyAuthorizationRepository(configuration.clientId, configuration.catalogRedirect, http)
    override val authorization: CatalogAuthorization =
        SpotifyCatalogAuthorization(applicationContext, authorizationRepository)
    override val playbackAuthorization: ProviderAuthorization =
        SpotifyPlaybackAuthorization(applicationContext, configuration)
    override val catalog: CatalogRepository =
        SpotifyCatalogRepository(SpotifyApiClient(authorizationRepository, http))

    override fun accepts(reference: TrackRef) = SpotifyTrackReferences.accepts(reference)

    override fun createPlaybackGateway(scope: CoroutineScope): PlaybackGateway =
        SpotifyPlaybackGateway(
            applicationContext,
            configuration.clientId,
            configuration.appRemoteRedirect,
        )
}
