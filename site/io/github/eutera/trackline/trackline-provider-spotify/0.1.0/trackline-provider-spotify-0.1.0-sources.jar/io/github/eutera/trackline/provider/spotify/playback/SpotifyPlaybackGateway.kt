package io.github.eutera.trackline.provider.spotify.playback

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.playback.PlaybackCommand
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import io.github.eutera.trackline.provider.spotify.SpotifyTrackReferences
import io.github.eutera.trackline.provider.spotify.spotifyClientConfigured
import io.github.eutera.trackline.provider.spotify.spotifyTrace

internal class SpotifyPlaybackGateway(
    context: Context,
    clientId: String,
    redirect: String,
    private val client: SpotifyRemoteClient = AppRemoteSpotifyClient(context, clientId, redirect),
) : PlaybackGateway {
    override val configured = spotifyClientConfigured(clientId) && redirect.isNotBlank()
    private val handler = Handler(Looper.getMainLooper())
    private var remote: SpotifyRemoteSession? = null
    private var subscription: SpotifyRemoteObservation? = null
    private var generation = 0

    init {
        if (!configured) spotifyTrace("playback unavailable code=CONFIGURATION", Log.WARN)
    }

    override fun connect(listener: PlaybackGateway.Listener) = connect(false, listener)

    fun connectForAuthorization(listener: PlaybackGateway.Listener) = connect(true, listener)

    private fun connect(allowAuthorization: Boolean, listener: PlaybackGateway.Listener) {
        disconnect()
        if (!configured) {
            reportFailure("connect", PlaybackFailure.CONFIGURATION, listener::onFailure)
            return
        }
        val request = generation
        spotifyTrace("SDK connect request=$request authorize=$allowAuthorization")
        if (!client.installed) {
            reportFailure("connect", PlaybackFailure.MISSING_APP, listener::onFailure)
            return
        }
        val timeout = Runnable {
            if (request == generation) {
                disconnect()
                reportFailure("connect", PlaybackFailure.TIMEOUT, listener::onFailure)
            }
        }
        handler.postDelayed(timeout, 60_000)
        try {
            client.connect(
                allowAuthorization,
                connected = { appRemote ->
                    onMain {
                        handler.removeCallbacks(timeout)
                        if (request != generation) {
                            appRemote.disconnect()
                            return@onMain
                        }
                        remote = appRemote
                        spotifyTrace("playback connected")
                        listener.onConnected()
                        if (request == generation) observe(appRemote, request, listener)
                    }
                },
                failed = { error ->
                    onMain {
                        handler.removeCallbacks(timeout)
                        if (request == generation) {
                            disconnect()
                            reportFailure("connect", playbackFailure(error), listener::onFailure)
                        }
                    }
                },
            )
        } catch (error: Exception) {
            handler.removeCallbacks(timeout)
            if (request == generation) {
                disconnect()
                reportFailure("connect", playbackFailure(error), listener::onFailure)
            }
        }
    }

    private fun observe(
        appRemote: SpotifyRemoteSession,
        request: Int,
        listener: PlaybackGateway.Listener,
    ) {
        val observation =
            appRemote.observe(
                playback = { snapshot ->
                    onMain {
                        if (request != generation) return@onMain
                        listener.onPlayback(snapshot)
                    }
                },
                failed = { error ->
                    onMain {
                        if (request == generation) {
                            reportFailure("observe", playbackFailure(error), listener::onFailure)
                        }
                    }
                },
            )
        if (request == generation) subscription = observation else observation.cancel()
    }

    override fun command(command: PlaybackCommand, completed: (PlaybackFailure?) -> Unit) {
        execute(command.name, completed) { session, result -> session.command(command, result) }
    }

    override fun select(reference: TrackRef, completed: (PlaybackFailure?) -> Unit) {
        val uri = SpotifyTrackReferences.toUri(reference)
        if (uri == null) {
            reportFailure("select", PlaybackFailure.UNKNOWN, completed)
            return
        }
        execute("select", completed) { session, result -> session.select(uri, result) }
    }

    private fun execute(
        operation: String,
        completed: (PlaybackFailure?) -> Unit,
        action: (SpotifyRemoteSession, (Throwable?) -> Unit) -> Unit,
    ) {
        val current = remote
        if (current == null || !current.connected) {
            reportFailure(operation, PlaybackFailure.DISCONNECTED, completed)
            return
        }
        val request = generation
        spotifyTrace("playback operation=$operation requested")
        var delivered = false
        fun finish(failure: PlaybackFailure?) {
            if (!delivered && request == generation) {
                delivered = true
                if (failure == null) {
                    spotifyTrace("playback operation=$operation acknowledged")
                    completed(null)
                } else {
                    reportFailure(operation, failure, completed)
                }
            }
        }
        val timeout = Runnable { finish(PlaybackFailure.TIMEOUT) }
        handler.postDelayed(timeout, 10_000)
        try {
            action(current) { error ->
                onMain {
                    handler.removeCallbacks(timeout)
                    finish(error?.let(::playbackFailure))
                }
            }
        } catch (error: Exception) {
            handler.removeCallbacks(timeout)
            finish(playbackFailure(error))
        }
    }

    override fun disconnect() {
        ++generation
        handler.removeCallbacksAndMessages(null)
        subscription?.cancel()
        subscription = null
        val previous = remote
        remote = null
        if (previous != null) {
            previous.disconnect()
            spotifyTrace("playback disconnected")
        }
    }

    private fun reportFailure(
        operation: String,
        failure: PlaybackFailure,
        report: (PlaybackFailure) -> Unit,
    ) {
        spotifyTrace("playback operation=$operation failed code=${failure.name}", Log.WARN)
        report(failure)
    }

    private fun onMain(block: () -> Unit) {
        if (Looper.myLooper() == handler.looper) block() else handler.post(block)
    }
}
