package io.github.eutera.trackline.provider.spotify.catalog

import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.github.eutera.trackline.provider.spotify.catalog.authorization.SpotifyAuthorizationRepository
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

internal class SpotifyApiClient(
    private val authorization: SpotifyAuthorizationRepository,
    private val http: SpotifyHttpClient,
    private val dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    suspend fun get(path: String): JSONObject {
        val current = authorization.generation
        val used = authorization.token()
        val response =
            try {
                withContext(dispatcher) {
                    http.request("https://api.spotify.com/v1/$path", bearer = used)
                }
            } catch (e: ProviderException) {
                if (e.category != ProviderError.AUTHORIZATION) throw e
                val fresh = authorization.token(rejected = used)
                try {
                    withContext(dispatcher) {
                        http.request("https://api.spotify.com/v1/$path", bearer = fresh)
                    }
                } catch (retry: ProviderException) {
                    if (
                        current == authorization.generation &&
                            retry.category == ProviderError.AUTHORIZATION
                    ) {
                        authorization.reject(current)
                    }
                    throw retry
                }
            }
        if (current != authorization.generation) {
            throw ProviderException(ProviderError.AUTHORIZATION)
        }
        return response
    }
}
