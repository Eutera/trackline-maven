package io.github.eutera.trackline.provider.spotify.catalog.authorization

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** The only exported part of Spotify's catalog flow. OAuth state is validated by the receiver. */
class SpotifyCatalogCallbackActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (intent.action == Intent.ACTION_VIEW) {
            intent.data?.let(SpotifyCatalogAuthorizationActivity::resumeWith)
        }
        finish()
    }
}
