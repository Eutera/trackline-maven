package io.github.eutera.trackline.provider.spotify.catalog.authorization

import android.net.Uri

internal fun matchesSpotifyCatalogRedirect(uri: Uri, redirect: Uri): Boolean =
    uri.scheme == redirect.scheme &&
        uri.encodedAuthority == redirect.encodedAuthority &&
        uri.encodedPath == redirect.encodedPath &&
        uri.fragment == null
