package io.github.eutera.trackline.provider.spotify.playback

import android.content.Context
import com.spotify.android.appremote.api.ConnectionParams
import com.spotify.android.appremote.api.Connector
import com.spotify.android.appremote.api.SpotifyAppRemote
import com.spotify.protocol.client.CallResult
import com.spotify.protocol.mappers.gson.GsonMapper
import com.spotify.protocol.types.Empty
import io.github.eutera.trackline.provider.api.playback.PlaybackCommand
import io.github.eutera.trackline.provider.api.playback.PlaybackSnapshot
import io.github.eutera.trackline.provider.spotify.SpotifyTrackReferences
import io.github.eutera.trackline.provider.spotify.playback.authorization.SpotifyAuthorizationContext

internal interface SpotifyRemoteClient {
    val installed: Boolean

    fun connect(
        allowAuthorization: Boolean,
        connected: (SpotifyRemoteSession) -> Unit,
        failed: (Throwable) -> Unit,
    )
}

internal interface SpotifyRemoteSession {
    val connected: Boolean

    fun observe(
        playback: (PlaybackSnapshot) -> Unit,
        failed: (Throwable) -> Unit,
    ): SpotifyRemoteObservation

    fun select(uri: String, completed: (Throwable?) -> Unit)

    fun command(command: PlaybackCommand, completed: (Throwable?) -> Unit)

    fun disconnect()
}

internal fun interface SpotifyRemoteObservation {
    fun cancel()
}

internal class AppRemoteSpotifyClient(
    context: Context,
    private val clientId: String,
    private val redirect: String,
) : SpotifyRemoteClient {
    private val applicationContext = context.applicationContext

    override val installed: Boolean
        get() = SpotifyAppRemote.isSpotifyInstalled(applicationContext)

    override fun connect(
        allowAuthorization: Boolean,
        connected: (SpotifyRemoteSession) -> Unit,
        failed: (Throwable) -> Unit,
    ) {
        val parameters =
            ConnectionParams.Builder(clientId)
                .setRedirectUri(redirect)
                .setJsonMapper(GsonMapper.create())
                .showAuthView(allowAuthorization)
                .build()
        SpotifyAppRemote.connect(
            SpotifyAuthorizationContext(applicationContext, allowAuthorization),
            parameters,
            object : Connector.ConnectionListener {
                override fun onConnected(appRemote: SpotifyAppRemote) =
                    connected(AppRemoteSpotifySession(appRemote))

                override fun onFailure(error: Throwable) = failed(error)
            },
        )
    }
}

private class AppRemoteSpotifySession(private val remote: SpotifyAppRemote) : SpotifyRemoteSession {
    override val connected: Boolean
        get() = remote.isConnected

    override fun observe(
        playback: (PlaybackSnapshot) -> Unit,
        failed: (Throwable) -> Unit,
    ): SpotifyRemoteObservation {
        val subscription = remote.playerApi.subscribeToPlayerState()
        subscription.setEventCallback { state ->
            val reference = state.track?.uri?.let(SpotifyTrackReferences::fromUri)
            playback(PlaybackSnapshot(state.isPaused, reference))
        }
        subscription.setErrorCallback(failed)
        return SpotifyRemoteObservation { subscription.cancel() }
    }

    override fun select(uri: String, completed: (Throwable?) -> Unit) =
        remote.playerApi.play(uri).completeWith(completed)

    override fun command(command: PlaybackCommand, completed: (Throwable?) -> Unit) =
        when (command) {
            PlaybackCommand.PLAY -> remote.playerApi.resume()
            PlaybackCommand.PAUSE -> remote.playerApi.pause()
        }.completeWith(completed)

    override fun disconnect() = SpotifyAppRemote.disconnect(remote)

    private fun CallResult<Empty>.completeWith(completed: (Throwable?) -> Unit) {
        setResultCallback { completed(null) }
        setErrorCallback(completed)
    }
}
