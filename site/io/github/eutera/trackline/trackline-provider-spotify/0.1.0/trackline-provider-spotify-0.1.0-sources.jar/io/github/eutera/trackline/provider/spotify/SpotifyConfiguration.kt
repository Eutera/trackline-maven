package io.github.eutera.trackline.provider.spotify

import android.content.Context
import android.content.pm.PackageManager

internal data class SpotifyConfiguration(
    val clientId: String,
    val catalogRedirect: String,
    val appRemoteRedirect: String,
) {
    companion object {
        fun fromManifest(context: Context): SpotifyConfiguration {
            @Suppress("DEPRECATION")
            val metadata =
                context.packageManager
                    .getApplicationInfo(context.packageName, PackageManager.GET_META_DATA)
                    .metaData
            return SpotifyConfiguration(
                clientId = metadata?.getString("trackline.spotify.clientId").orEmpty(),
                catalogRedirect =
                    metadata?.getString("trackline.spotify.catalogRedirect").orEmpty(),
                appRemoteRedirect =
                    metadata?.getString("trackline.spotify.appRemoteRedirect").orEmpty(),
            )
        }
    }
}
