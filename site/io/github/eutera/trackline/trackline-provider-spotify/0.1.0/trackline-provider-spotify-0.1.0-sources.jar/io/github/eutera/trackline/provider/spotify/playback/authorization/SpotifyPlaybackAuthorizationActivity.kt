package io.github.eutera.trackline.provider.spotify.playback.authorization

import android.app.Activity
import android.os.Bundle
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import io.github.eutera.trackline.provider.api.playback.PlaybackSnapshot
import io.github.eutera.trackline.provider.spotify.SpotifyConfiguration
import io.github.eutera.trackline.provider.spotify.playback.SpotifyPlaybackGateway

/** Gives the App Remote SDK a foreground activity while it obtains playback consent. */
@Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
class SpotifyPlaybackAuthorizationActivity : Activity() {
    private lateinit var attempt: PlaybackConsentAttempt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val previousAttempt = lastNonConfigurationInstance as? PlaybackConsentAttempt
        if (savedInstanceState != null && previousAttempt == null) {
            finish()
            return
        }
        val configuration = SpotifyConfiguration.fromManifest(this)
        attempt =
            previousAttempt
                ?: PlaybackConsentAttempt(
                    SpotifyPlaybackGateway(
                        applicationContext,
                        configuration.clientId,
                        configuration.appRemoteRedirect,
                    )
                )
        attempt.deliverResult = { result ->
            setResult(result)
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        if (::attempt.isInitialized && !isFinishing) attempt.start()
    }

    override fun onRetainNonConfigurationInstance(): Any? =
        if (::attempt.isInitialized) attempt else null

    override fun onDestroy() {
        if (::attempt.isInitialized) {
            attempt.deliverResult = null
            if (!isChangingConfigurations) attempt.close()
        }
        super.onDestroy()
    }
}

private class PlaybackConsentAttempt(private val gateway: SpotifyPlaybackGateway) :
    PlaybackGateway.Listener {
    private var started = false
    private var result: Int? = null
    var deliverResult: ((Int) -> Unit)? = null
        set(value) {
            field = value
            if (value != null) result?.let(value)
        }

    fun start() {
        if (started) return
        started = true
        gateway.connectForAuthorization(this)
    }

    override fun onConnected() = finish(Activity.RESULT_OK)

    override fun onFailure(failure: PlaybackFailure) = finish(Activity.RESULT_FIRST_USER)

    override fun onPlayback(snapshot: PlaybackSnapshot) = Unit

    fun close() = gateway.disconnect()

    private fun finish(code: Int) {
        close()
        result = code
        deliverResult?.invoke(code)
    }
}
