package io.github.eutera.trackline.provider.spotify.catalog

import android.util.Log
import io.github.eutera.trackline.provider.api.catalog.CatalogPage
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.github.eutera.trackline.provider.spotify.spotifyTrace
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONException

internal class SpotifyCatalogRepository(private val api: SpotifyApiClient) : CatalogRepository {
    override fun acceptsPlaylistInput(playlist: String) =
        SpotifyPlaylistInput.spotifyId(playlist) != null

    override suspend fun page(playlist: String, cursor: String?): CatalogPage {
        currentCoroutineContext().ensureActive()
        spotifyTrace("catalog page requested continuation=${cursor != null}")
        return try {
            loadPage(playlist, cursor).also {
                spotifyTrace("catalog page loaded items=${it.items.size}")
            }
        } catch (error: CancellationException) {
            throw error
        } catch (error: ProviderException) {
            spotifyTrace("catalog page failed code=${error.category}", Log.WARN)
            throw error
        } catch (_: JSONException) {
            spotifyTrace("catalog page failed code=${ProviderError.UNAVAILABLE}", Log.WARN)
            throw ProviderException(ProviderError.UNAVAILABLE)
        } catch (_: Exception) {
            spotifyTrace("catalog page failed code=${ProviderError.TEMPORARY}", Log.WARN)
            throw ProviderException(ProviderError.TEMPORARY)
        }
    }

    private suspend fun loadPage(playlist: String, cursor: String?): CatalogPage {
        val id =
            SpotifyPlaylistInput.spotifyId(playlist)
                ?: throw ProviderException(ProviderError.UNAVAILABLE)
        val offset =
            cursor?.toIntOrNull()?.takeIf { it >= 0 }
                ?: if (cursor == null) 0 else throw ProviderException(ProviderError.TEMPORARY)
        val beforeDetails = api.get("playlists/$id?fields=snapshot_id,name")
        val before = beforeDetails.optString("snapshot_id").takeIf { it.isNotEmpty() }
        val page = api.get("playlists/$id/items?limit=50&offset=$offset")
        val afterDetails = api.get("playlists/$id?fields=snapshot_id,name")
        val after = afterDetails.optString("snapshot_id").takeIf { it.isNotEmpty() }
        if (before != null && after != null && before != after) {
            throw ProviderException(ProviderError.TEMPORARY)
        }
        val entries = page.getJSONArray("items")
        val items = spotifyPlaylistItems(entries)
        // Cursor is generated locally; never follow a provider-supplied URL with bearer
        // credentials.
        val playlistName =
            afterDetails.optString("name").takeIf {
                !afterDetails.isNull("name") && it.isNotBlank()
            }
                ?: beforeDetails.optString("name").takeIf {
                    !beforeDetails.isNull("name") && it.isNotBlank()
                }
        return CatalogPage(
            items,
            if (!page.isNull("next") && page.optString("next").isNotEmpty()) {
                val nextOffset = offset.toLong() + entries.length()
                if (nextOffset > Int.MAX_VALUE) throw ProviderException(ProviderError.UNAVAILABLE)
                nextOffset.toString()
            } else {
                null
            },
            after ?: before,
            playlistName,
        )
    }
}
