package io.github.eutera.trackline.provider.spotify.playback.authorization

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.ServiceConnection
import android.os.Build
import io.github.eutera.trackline.provider.spotify.spotifyTrace

/** App Remote 0.8.0 predates Android 14's explicit bound-service activity opt-in. */
internal class SpotifyAuthorizationContext(
    context: Context,
    private val allowAuthorization: Boolean,
) : ContextWrapper(context) {
    // The SDK resolves applicationContext again immediately before bindService.
    // The base is already application-scoped, so retaining this wrapper is safe.
    override fun getApplicationContext(): Context = this

    override fun bindService(service: Intent, connection: ServiceConnection, flags: Int): Boolean {
        val spotifyService =
            (service.`package` ?: service.component?.packageName) == "com.spotify.music" &&
                service.action == "com.spotify.mobile.appprotocol.action.BIND_PROTOCOL_SERVICE"
        // Only the user-initiated Connect flow may open Spotify's consent screen.
        // Silent reconnects and unrelated services retain the platform defaults.
        val bindingFlags =
            if (Build.VERSION.SDK_INT >= 34 && allowAuthorization && spotifyService) {
                flags or BIND_ALLOW_ACTIVITY_STARTS
            } else {
                flags
            }
        spotifyTrace(
            "SDK bind authorization=$allowAuthorization spotifyService=$spotifyService flags=$bindingFlags"
        )
        return super.bindService(service, connection, bindingFlags)
    }
}
