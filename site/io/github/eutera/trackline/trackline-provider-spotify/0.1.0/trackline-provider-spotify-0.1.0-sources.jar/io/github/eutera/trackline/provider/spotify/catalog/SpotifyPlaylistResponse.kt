package io.github.eutera.trackline.provider.spotify.catalog

import io.github.eutera.trackline.provider.api.TrackSnapshot
import io.github.eutera.trackline.provider.api.catalog.CatalogItem
import io.github.eutera.trackline.provider.api.catalog.SkipReason
import io.github.eutera.trackline.provider.spotify.SpotifyTrackReferences
import org.json.JSONArray

internal fun spotifyPlaylistItems(entries: JSONArray): List<CatalogItem> {
    return (0 until entries.length()).map { index ->
        val wrapper = entries.optJSONObject(index)
        val item = wrapper?.optJSONObject("item") ?: wrapper?.optJSONObject("track")
        when {
            item == null -> CatalogItem.Skipped(SkipReason.MISSING)
            wrapper?.optBoolean("is_local") == true || item.optBoolean("is_local") -> {
                CatalogItem.Skipped(SkipReason.LOCAL_FILE)
            }
            item.optString("type") != "track" -> CatalogItem.Skipped(SkipReason.UNSUPPORTED_MEDIA)
            item.has("is_playable") && !item.optBoolean("is_playable") -> {
                CatalogItem.Skipped(SkipReason.UNPLAYABLE)
            }
            !item.optString("id").matches(Regex("[A-Za-z0-9]{22}")) -> {
                CatalogItem.Skipped(SkipReason.INVALID_REFERENCE)
            }
            else -> {
                val album = item.optJSONObject("album")
                val artists = item.optJSONArray("artists")
                CatalogItem.Track(
                    TrackSnapshot(
                        checkNotNull(SpotifyTrackReferences.fromId(item.getString("id"))),
                        item.optString("name"),
                        (0 until (artists?.length() ?: 0)).map {
                            artists!!.optJSONObject(it)?.optString("name").orEmpty()
                        },
                        releaseYear = album?.optString("release_date")?.take(4)?.toIntOrNull(),
                    )
                )
            }
        }
    }
}
