package io.github.eutera.trackline.provider.spotify.playback

import com.spotify.android.appremote.api.error.AuthenticationFailedException
import com.spotify.android.appremote.api.error.CouldNotFindSpotifyApp
import com.spotify.android.appremote.api.error.NotLoggedInException
import com.spotify.android.appremote.api.error.OfflineModeException
import com.spotify.android.appremote.api.error.SpotifyConnectionTerminatedException
import com.spotify.android.appremote.api.error.SpotifyDisconnectedException
import com.spotify.android.appremote.api.error.SpotifyRemoteServiceException
import com.spotify.android.appremote.api.error.UnsupportedFeatureVersionException
import com.spotify.android.appremote.api.error.UserNotAuthorizedException
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure

internal fun playbackFailure(error: Throwable): PlaybackFailure {
    val causes = generateSequence(error) { it.cause }.take(8).toList()
    return when {
        causes.any { it is CouldNotFindSpotifyApp } -> PlaybackFailure.MISSING_APP
        causes.any { it is NotLoggedInException } -> PlaybackFailure.LOG_IN
        causes.any { it is UserNotAuthorizedException } -> PlaybackFailure.AUTHORIZATION
        causes.any { it is AuthenticationFailedException } -> PlaybackFailure.CONFIGURATION
        causes.any { it is OfflineModeException } -> PlaybackFailure.OFFLINE
        causes.any { it is UnsupportedFeatureVersionException } -> PlaybackFailure.UPDATE_REQUIRED
        causes.any {
            it is SpotifyDisconnectedException ||
                it is SpotifyConnectionTerminatedException ||
                it is SpotifyRemoteServiceException
        } -> {
            PlaybackFailure.DISCONNECTED
        }
        else -> PlaybackFailure.UNKNOWN
    }
}
