# Demo music credits

The complete recordings were re-encoded to stereo AAC-LC at a target of 80 kbit/s in
M4A containers. Track titles, artists and release years are also stored in the audio
metadata. The following licenses apply to the music assets.

| Bundled asset | Recording and original release year | Attribution and license |
| --- | --- | --- |
| `sneaky_snitch.m4a` | [Sneaky Snitch](https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100772), 2010 | Kevin MacLeod ([incompetech.com](https://incompetech.com/)), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `crazy_glue.m4a` | [Crazy Glue](https://commons.wikimedia.org/wiki/File:Josh_Woodward_-_The_Wake_-_04_-_Crazy_Glue.ogg), [2012](https://joshwoodward.bandcamp.com/album/the-wake) | [Josh Woodward](https://joshwoodward.bandcamp.com/), [CC BY 3.0 US](https://creativecommons.org/licenses/by/3.0/us/) |
| `cylinder_five.m4a` | [Cylinder Five](https://commons.wikimedia.org/wiki/File:Chris_Zabriskie_-_05_-_Cylinder_Five.ogg), [2014](https://chriszabriskie.com/cylinders/) | © 2014 [Chris Zabriskie](https://chriszabriskie.com/), from the album *Cylinders*, [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `ooame.m4a` | [Ooame](https://opengameart.org/content/ooame), 2021 | [TAD](https://www.youtube.com/c/Tadon), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |
| `cinematic_piano_trailer.m4a` | [Cinematic Piano Trailer](https://opengameart.org/content/cinematic-trailer-music-collection), [2022](https://gregorquendel.bandcamp.com/album/cinematic-trailer-music) | [Gregor Quendel](https://www.gregorquendel.com/), [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/) |

The same credits are available under Music credits in the app's navigation drawer.
