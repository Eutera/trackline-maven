package io.github.eutera.trackline.provider.demo

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.playback.PlaybackCommand
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import io.github.eutera.trackline.provider.api.playback.PlaybackSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal class DemoPlaybackGateway(
    private val context: Context,
    private val scope: CoroutineScope,
) : PlaybackGateway {
    private var connecting: Job? = null
    private var player: ExoPlayer? = null
    private var selected: TrackRef? = null

    override fun connect(listener: PlaybackGateway.Listener) {
        disconnect()
        connecting =
            scope.launch {
                delay(450)
                val engine =
                    try {
                        ExoPlayer.Builder(context).build()
                    } catch (_: IllegalStateException) {
                        listener.onFailure(PlaybackFailure.UNKNOWN)
                        return@launch
                    }
                player = engine
                engine.setAudioAttributes(AudioAttributes.DEFAULT, true)
                engine.setHandleAudioBecomingNoisy(true)
                engine.addListener(
                    object : Player.Listener {
                        override fun onEvents(player: Player, events: Player.Events) {
                            val reference = selected ?: return
                            if (
                                this@DemoPlaybackGateway.player !== player ||
                                    player.currentMediaItem?.mediaId != reference.id
                            ) {
                                return
                            }
                            listener.onPlayback(
                                PlaybackSnapshot(
                                    paused = !player.isPlaying,
                                    reference = reference,
                                    buffering =
                                        player.playbackState == Player.STATE_BUFFERING ||
                                            player.playbackState == Player.STATE_IDLE,
                                )
                            )
                        }

                        override fun onPlayerError(error: PlaybackException) {
                            if (player === engine) listener.onFailure(PlaybackFailure.UNKNOWN)
                        }
                    }
                )
                listener.onConnected()
            }
    }

    override fun select(reference: TrackRef, completed: (PlaybackFailure?) -> Unit) {
        val track = demoTracks.firstOrNull { it.reference == reference }
        if (track == null) {
            completed(PlaybackFailure.UPDATE_REQUIRED)
            return
        }
        val engine = player
        if (engine == null) {
            completed(PlaybackFailure.DISCONNECTED)
            return
        }
        selected = reference
        engine.setMediaItem(
            MediaItem.Builder().setMediaId(reference.id).setUri(track.assetUri).build()
        )
        engine.prepare()
        engine.play()
        completed(null)
    }

    override fun command(command: PlaybackCommand, completed: (PlaybackFailure?) -> Unit) {
        val engine = player
        if (engine == null || (selected == null && command == PlaybackCommand.PLAY)) {
            completed(PlaybackFailure.DISCONNECTED)
            return
        }
        when (command) {
            PlaybackCommand.PLAY -> {
                if (engine.playbackState == Player.STATE_ENDED) engine.seekToDefaultPosition()
                engine.play()
            }
            PlaybackCommand.PAUSE -> engine.pause()
        }
        completed(null)
    }

    override fun disconnect() {
        connecting?.cancel()
        connecting = null
        selected = null
        val previous = player
        player = null
        previous?.release()
    }
}
