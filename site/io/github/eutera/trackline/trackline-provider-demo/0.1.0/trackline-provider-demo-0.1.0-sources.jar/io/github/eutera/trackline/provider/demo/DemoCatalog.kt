package io.github.eutera.trackline.provider.demo

import android.content.Context
import io.github.eutera.trackline.provider.api.MusicCredit
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.TrackSnapshot
import io.github.eutera.trackline.provider.api.catalog.CatalogItem
import io.github.eutera.trackline.provider.api.catalog.CatalogPage
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

internal const val DEMO_PROVIDER_ID = "demo"
private const val CC_BY_4 = "https://creativecommons.org/licenses/by/4.0/"

internal class DemoTrack(
    id: String,
    val title: String,
    val artist: String,
    releaseYear: Int,
    private val artistUrl: String,
    private val sourceUrl: String,
    private val licenseName: String = "CC BY 4.0",
    private val licenseUrl: String = CC_BY_4,
    private val attributionResource: Int? = null,
) {
    val reference = TrackRef(DEMO_PROVIDER_ID, id)
    val assetUri = "asset:///trackline-demo/$id.m4a"
    val snapshot = TrackSnapshot(reference, title, listOf(artist), releaseYear)

    fun credit(context: Context) =
        MusicCredit(
            title,
            attributionResource?.let { context.getString(it, artist) } ?: artist,
            artistUrl,
            sourceUrl,
            licenseName,
            licenseUrl,
        )
}

internal val demoTracks =
    listOf(
        DemoTrack(
            "sneaky_snitch",
            "Sneaky Snitch",
            "Kevin MacLeod",
            2010,
            "https://incompetech.com/",
            "https://incompetech.com/music/royalty-free/index.html?isrc=USUAN1100772",
        ),
        DemoTrack(
            "crazy_glue",
            "Crazy Glue",
            "Josh Woodward",
            2012,
            "https://joshwoodward.bandcamp.com/",
            "https://commons.wikimedia.org/wiki/File:Josh_Woodward_-_The_Wake_-_04_-_Crazy_Glue.ogg",
            "CC BY 3.0 US",
            "https://creativecommons.org/licenses/by/3.0/us/",
        ),
        DemoTrack(
            "cylinder_five",
            "Cylinder Five",
            "Chris Zabriskie",
            2014,
            "https://chriszabriskie.com/",
            "https://chriszabriskie.com/cylinders/",
            attributionResource = R.string.demo_cylinders_album_credit,
        ),
        DemoTrack(
            "ooame",
            "Ooame",
            "TAD",
            2021,
            "https://www.youtube.com/c/Tadon",
            "https://opengameart.org/content/ooame",
        ),
        DemoTrack(
            "cinematic_piano_trailer",
            "Cinematic Piano Trailer",
            "Gregor Quendel",
            2022,
            "https://www.gregorquendel.com/",
            "https://opengameart.org/content/cinematic-trailer-music-collection",
        ),
    )

internal class DemoCatalog(playlistName: String) : CatalogRepository {
    private val playlist =
        CatalogPage(
            items = demoTracks.map { CatalogItem.Track(it.snapshot) },
            next = null,
            revision = "demo-v1",
            playlistName = playlistName,
        )

    override fun acceptsPlaylistInput(playlist: String) = true

    override suspend fun page(playlist: String, cursor: String?): CatalogPage {
        currentCoroutineContext().ensureActive()
        if (cursor != null) throw ProviderException(ProviderError.UNSUPPORTED)
        return this.playlist
    }
}
