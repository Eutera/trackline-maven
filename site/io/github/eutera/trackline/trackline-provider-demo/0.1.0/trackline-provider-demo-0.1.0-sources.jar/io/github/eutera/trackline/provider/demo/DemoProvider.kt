package io.github.eutera.trackline.provider.demo

import android.content.Context
import io.github.eutera.trackline.provider.api.MusicCredits
import io.github.eutera.trackline.provider.api.MusicProvider
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.catalog.CatalogAuthorization
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import kotlinx.coroutines.CoroutineScope

class DemoProvider(context: Context) : MusicProvider {
    private val applicationContext = context.applicationContext

    override val id = DEMO_PROVIDER_ID
    override val displayName = context.getString(R.string.demo_provider_name)
    override val catalog: CatalogRepository =
        DemoCatalog(context.getString(R.string.demo_playlist_name))
    override val authorization: CatalogAuthorization = DemoCatalogAuthorization(applicationContext)
    override val musicCredits =
        MusicCredits(
            demoTracks.map { it.credit(context) },
            context.getString(R.string.demo_music_encoding_credit),
        )

    override fun accepts(reference: TrackRef) = demoTracks.any { it.reference == reference }

    override fun createPlaybackGateway(scope: CoroutineScope): PlaybackGateway =
        DemoPlaybackGateway(applicationContext, scope)
}
