package io.github.eutera.trackline.provider.demo

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import io.github.eutera.trackline.provider.api.catalog.CatalogAuthorization
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

internal class DemoCatalogAuthorization(private val context: Context) : CatalogAuthorization {
    override val authorized = MutableStateFlow(true).asStateFlow()

    override fun createIntent() = Intent(context, DemoCatalogAuthorizationActivity::class.java)

    override suspend fun complete(resultCode: Int, data: Intent?) = true

    override fun disconnect() = Unit
}

class DemoCatalogAuthorizationActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.demo_catalog_authorization)
        findViewById<Button>(R.id.demo_catalog_access_back).setOnClickListener {
            setResult(RESULT_OK)
            finish()
        }
    }
}
