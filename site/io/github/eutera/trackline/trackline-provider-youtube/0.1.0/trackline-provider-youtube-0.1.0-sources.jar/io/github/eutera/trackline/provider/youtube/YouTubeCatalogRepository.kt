package io.github.eutera.trackline.provider.youtube

import io.github.eutera.trackline.provider.api.catalog.CatalogItem
import io.github.eutera.trackline.provider.api.catalog.CatalogPage
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject

internal class YouTubeCatalogRepository(
    private val trace: YouTubeTrace = YouTubeTrace(),
    private val browse: suspend (String?, String?) -> JsonObject,
) : CatalogRepository {
    override fun acceptsPlaylistInput(playlist: String) =
        YouTubeReferences.playlist(playlist) != null

    override suspend fun page(playlist: String, cursor: String?): CatalogPage {
        trace.debug("catalog page requested continuation=${cursor != null}")
        return try {
            loadPage(playlist, cursor).also {
                trace.debug("catalog page loaded items=${it.items.size}")
            }
        } catch (error: CancellationException) {
            throw error
        } catch (error: ProviderException) {
            trace.warning("catalog page failed code=${error.category}")
            throw error
        } catch (_: Exception) {
            trace.warning("catalog page failed code=${ProviderError.TEMPORARY}")
            throw ProviderException(ProviderError.TEMPORARY)
        }
    }

    private suspend fun loadPage(playlist: String, cursor: String?): CatalogPage =
        withContext(Dispatchers.IO) {
            val id =
                YouTubeReferences.playlist(playlist)
                    ?: throw ProviderException(ProviderError.UNSUPPORTED)
            if (cursor != null && (cursor.length > 16_384 || cursor.isBlank())) {
                throw ProviderException(ProviderError.UNSUPPORTED)
            }
            val decoded =
                YouTubeCatalogDecoder.decode(
                    browse(if (cursor == null) "VL$id" else null, cursor),
                    continuation = cursor != null,
                )
            val years = mutableMapOf<String, Int?>()
            for (batch in decoded.albums.values.distinct().chunked(4)) {
                val fetched = coroutineScope {
                    batch.map { album -> async { album to albumYear(album) } }.awaitAll()
                }
                years.putAll(fetched)
            }
            decoded.page.copy(
                items =
                    decoded.page.items.map { item ->
                        if (item !is CatalogItem.Track) return@map item
                        val album = decoded.albums[item.snapshot.ref] ?: return@map item
                        val year = years[album] ?: return@map item
                        item.copy(snapshot = item.snapshot.copy(releaseYear = year))
                    }
            )
        }

    private suspend fun albumYear(album: String): Int? =
        try {
            YouTubeCatalogDecoder.albumYear(browse(album, null))
        } catch (error: CancellationException) {
            throw error
        } catch (_: Exception) {
            null
        }
}
