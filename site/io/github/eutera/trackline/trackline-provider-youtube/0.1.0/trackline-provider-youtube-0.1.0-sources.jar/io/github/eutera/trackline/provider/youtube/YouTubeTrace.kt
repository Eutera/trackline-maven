package io.github.eutera.trackline.provider.youtube

import android.util.Log

/** Callers log operation names and typed results without request or response content. */
internal class YouTubeTrace(private val write: (Int, String) -> Unit = { _, _ -> }) {
    fun debug(message: String) = write(Log.DEBUG, message)

    fun warning(message: String) = write(Log.WARN, message)
}
