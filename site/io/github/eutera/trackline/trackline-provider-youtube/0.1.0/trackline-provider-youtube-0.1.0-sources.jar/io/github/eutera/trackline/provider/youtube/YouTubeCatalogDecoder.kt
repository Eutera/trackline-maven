package io.github.eutera.trackline.provider.youtube

import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.TrackSnapshot
import io.github.eutera.trackline.provider.api.catalog.CatalogItem
import io.github.eutera.trackline.provider.api.catalog.CatalogPage
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.github.eutera.trackline.provider.api.catalog.SkipReason
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

internal data class YouTubeCatalogPage(val page: CatalogPage, val albums: Map<TrackRef, String>)

internal object YouTubeCatalogDecoder {
    fun decode(root: JsonObject, continuation: Boolean): YouTubeCatalogPage {
        if (root["error"] != null) throw ProviderException(ProviderError.UNAVAILABLE)
        val shelf =
            root.findObject("musicPlaylistShelfRenderer")
                ?: root.findObject("musicPlaylistShelfContinuation")
                ?: root.findObject("musicShelfContinuation")
        val appended =
            root.findObject("appendContinuationItemsAction")?.get("continuationItems") as? JsonArray
        val contents =
            when (val value = shelf?.get("contents")) {
                is JsonArray -> value
                null ->
                    if (shelf != null) JsonArray(emptyList())
                    else appended ?: throw ProviderException(ProviderError.UNAVAILABLE)
                else -> throw ProviderException(ProviderError.UNAVAILABLE)
            }
        val albums = mutableMapOf<TrackRef, String>()
        val items =
            contents.mapNotNull { element ->
                val container =
                    element as? JsonObject
                        ?: return@mapNotNull CatalogItem.Skipped(SkipReason.MISSING)
                if (container["continuationItemRenderer"] != null) return@mapNotNull null
                val row =
                    container["musicResponsiveListItemRenderer"] as? JsonObject
                        ?: return@mapNotNull CatalogItem.Skipped(SkipReason.UNSUPPORTED_MEDIA)
                val id =
                    (row["playlistItemData"] as? JsonObject)?.get("videoId").string()
                        ?: row.findObject("watchEndpoint")?.get("videoId").string()
                        ?: return@mapNotNull CatalogItem.Skipped(SkipReason.MISSING)
                val ref = TrackRef(YouTubeReferences.PROVIDER_ID, id)
                if (!YouTubeReferences.accepts(ref)) {
                    return@mapNotNull CatalogItem.Skipped(SkipReason.INVALID_REFERENCE)
                }
                if (
                    row["musicItemRendererDisplayPolicy"].string() ==
                        "MUSIC_ITEM_RENDERER_DISPLAY_POLICY_GREY_OUT"
                ) {
                    return@mapNotNull CatalogItem.Skipped(SkipReason.UNPLAYABLE)
                }
                val type =
                    row.findObject("watchEndpointMusicSupportedConfigs")
                        ?.findObject("watchEndpointMusicConfig")
                        ?.get("musicVideoType")
                        .string()
                if (type == "MUSIC_VIDEO_TYPE_PODCAST_EPISODE") {
                    return@mapNotNull CatalogItem.Skipped(SkipReason.UNSUPPORTED_MEDIA)
                }
                val columns = row["flexColumns"] as? JsonArray ?: JsonArray(emptyList())
                val title =
                    columns
                        .firstOrNull()
                        ?.findObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.get("text")
                        .text()
                val artistRuns =
                    columns
                        .getOrNull(1)
                        ?.findObject("musicResponsiveListItemFlexColumnRenderer")
                        ?.get("text")
                        ?.let { it as? JsonObject }
                        ?.get("runs") as? JsonArray
                val artists =
                    artistRuns
                        .orEmpty()
                        .mapNotNull { run ->
                            val artist = run as? JsonObject ?: return@mapNotNull null
                            val browseId =
                                artist.findObject("browseEndpoint")?.get("browseId").string()
                            artist["text"].string()?.trim()?.takeIf {
                                it.isNotEmpty() &&
                                    it !in setOf("•", "&", ",") &&
                                    (browseId == null || browseId.startsWith("UC"))
                            }
                        }
                        .distinct()
                if (title.isBlank() || artists.isEmpty()) {
                    return@mapNotNull CatalogItem.Skipped(SkipReason.MISSING)
                }
                row.findObjects("browseEndpoint")
                    .mapNotNull { it["browseId"].string() }
                    .firstOrNull { it.startsWith("MPRE") }
                    ?.let { albums[ref] = it }
                CatalogItem.Track(TrackSnapshot(ref, title, artists))
            }
        val next =
            shelf?.findObject("nextContinuationData")?.get("continuation").string()
                ?: contents.findObject("continuationCommand")?.get("token").string()
        val header =
            root["header"]?.findObject("musicDetailHeaderRenderer")
                ?: root.findObject("musicResponsiveHeaderRenderer")
        val name =
            if (continuation) null else header?.get("title").text().takeIf { it.isNotBlank() }
        return YouTubeCatalogPage(
            CatalogPage(items, next, revision = null, playlistName = name),
            albums,
        )
    }

    fun albumYear(root: JsonObject): Int? {
        val header =
            root.findObject("musicResponsiveHeaderRenderer")
                ?: root.findObject("musicDetailHeaderRenderer")
        return header
            ?.get("subtitle")
            .text()
            .split('•')
            .map(String::trim)
            .lastOrNull { it.matches(Regex("[12][0-9]{3}")) }
            ?.toInt()
    }
}

internal fun JsonElement?.string(): String? = (this as? JsonPrimitive)?.contentOrNull

private fun JsonElement?.text(): String {
    val value = this as? JsonObject ?: return ""
    return value["simpleText"].string()
        ?: (value["runs"] as? JsonArray).orEmpty().joinToString("") {
            (it as? JsonObject)?.get("text").string().orEmpty()
        }
}

internal fun JsonElement?.findObject(key: String): JsonObject? = findObjects(key).firstOrNull()

private fun JsonElement?.findObjects(key: String): Sequence<JsonObject> = sequence {
    when (val element = this@findObjects) {
        is JsonObject -> {
            (element[key] as? JsonObject)?.let { yield(it) }
            for (child in element.values) {
                yieldAll(child.findObjects(key))
            }
        }
        is JsonArray -> {
            for (child in element) {
                yieldAll(child.findObjects(key))
            }
        }
        else -> Unit
    }
}
