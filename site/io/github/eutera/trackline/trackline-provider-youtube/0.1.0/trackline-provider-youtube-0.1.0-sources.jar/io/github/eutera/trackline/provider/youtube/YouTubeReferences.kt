package io.github.eutera.trackline.provider.youtube

import io.github.eutera.trackline.provider.api.TrackRef
import java.net.URI
import java.net.URLDecoder

internal object YouTubeReferences {
    const val PROVIDER_ID = "youtube-music"
    private val videoId = Regex("[A-Za-z0-9_-]{11}")
    private val playlistId = Regex("[A-Za-z0-9_-]{10,256}")
    private val hosts =
        setOf("music.youtube.com", "youtube.com", "www.youtube.com", "m.youtube.com")

    fun accepts(reference: TrackRef) =
        reference.provider == PROVIDER_ID && videoId.matches(reference.id)

    fun playlist(input: String): String? {
        if (input.length > 8192) return null
        val value = input.trim()
        if (playlistId.matches(value)) return value
        val urls = Regex("https://[^\\s<>\"]+").findAll(value).toList()
        if (urls.size != 1) return null
        val uri =
            runCatching { URI(urls.single().value.trimEnd('.', ',', ')')) }.getOrNull()
                ?: return null
        if (
            uri.scheme != "https" ||
                uri.host !in hosts ||
                uri.userInfo != null ||
                uri.port != -1 ||
                uri.path !in setOf("/playlist", "/watch")
        ) {
            return null
        }
        val ids =
            uri.rawQuery.orEmpty().split('&').mapNotNull { part ->
                if (part.substringBefore('=') != "list") {
                    null
                } else {
                    runCatching { URLDecoder.decode(part.substringAfter('=', ""), "UTF-8") }
                        .getOrNull()
                }
            }
        return ids.singleOrNull()?.takeIf(playlistId::matches)
    }
}
