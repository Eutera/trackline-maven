package io.github.eutera.trackline.provider.youtube

import com.metrolist.innertubex.InnerTube
import com.metrolist.innertubex.InnerTubeHttpException
import com.metrolist.innertubex.bodyAsTextLimited
import com.metrolist.innertubex.cipher.PlayerConfigRepository
import com.metrolist.innertubex.cipher.RemotePlayerConfigStore
import com.metrolist.innertubex.cipher.YouTubeCipherService
import com.metrolist.innertubex.extraction.AudioQuality
import com.metrolist.innertubex.extraction.ContentHints
import com.metrolist.innertubex.extraction.ExtractedStream
import com.metrolist.innertubex.extraction.InnerTubeExtractor
import com.metrolist.innertubex.extraction.YtConfigParserImpl
import com.metrolist.innertubex.models.YouTubeClient
import io.github.eutera.trackline.provider.api.catalog.ProviderError
import io.github.eutera.trackline.provider.api.catalog.ProviderException
import io.ktor.client.HttpClient
import io.ktor.client.engine.HttpClientEngine
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.serialization.kotlinx.json.json
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

internal class YouTubeMusicClient(
    engine: HttpClientEngine = OkHttp.create(),
    private val trace: YouTubeTrace = YouTubeTrace(),
) {
    val http =
        HttpClient(engine) {
            install(ContentNegotiation) {
                json(
                    Json {
                        ignoreUnknownKeys = true
                        explicitNulls = false
                        encodeDefaults = true
                    }
                )
            }
            install(HttpTimeout) {
                connectTimeoutMillis = 10_000
                socketTimeoutMillis = 20_000
                requestTimeoutMillis = 30_000
            }
        }
    private val innerTube =
        InnerTube(http).apply {
            // YouTube Music rejects some regional language tags, including en-SK.
            locale = locale.copy(hl = "en")
        }
    private val configs =
        RemotePlayerConfigStore(http, repository = PlayerConfigRepository.disabled())
    private val cipher = YouTubeCipherService(http, configs)
    private val extractor =
        InnerTubeExtractor(
            configParser = YtConfigParserImpl(http, innerTube, configs, cipherService = cipher),
            cipherService = cipher,
            innerTube = innerTube,
        )

    suspend fun browse(id: String?, continuation: String? = null): JsonObject =
        withContext(Dispatchers.IO) {
            try {
                val response =
                    innerTube.browse(
                        YouTubeClient.WEB_REMIX,
                        browseId = id,
                        continuation = continuation,
                    )
                Json.parseToJsonElement(response.bodyAsTextLimited(4 * 1024 * 1024)) as? JsonObject
                    ?: throw ProviderException(ProviderError.UNAVAILABLE)
            } catch (error: CancellationException) {
                throw error
            } catch (error: InnerTubeHttpException) {
                trace.warning("http operation=browse status=${error.status.value}")
                throw ProviderException(
                    when (error.status.value) {
                        401,
                        403 -> ProviderError.PERMISSION
                        404 -> ProviderError.UNAVAILABLE
                        429 -> ProviderError.RATE_LIMIT
                        else -> ProviderError.TEMPORARY
                    }
                )
            } catch (_: IOException) {
                throw ProviderException(ProviderError.OFFLINE)
            } catch (_: IllegalArgumentException) {
                throw ProviderException(ProviderError.UNAVAILABLE)
            }
        }

    suspend fun stream(id: String): ExtractedStream =
        withContext(Dispatchers.IO) {
            extractor.extract(
                id,
                hints = ContentHints(wantVideo = false),
                audioQuality = AudioQuality.HIGH,
            ) ?: throw ProviderException(ProviderError.UNAVAILABLE)
        }

    fun close() {
        innerTube.close()
        http.close()
    }
}
