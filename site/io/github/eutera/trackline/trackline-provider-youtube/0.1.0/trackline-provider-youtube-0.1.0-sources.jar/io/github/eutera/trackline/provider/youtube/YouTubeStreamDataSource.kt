package io.github.eutera.trackline.provider.youtube

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSourceException
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import com.metrolist.innertubex.extraction.ExtractedStream
import com.metrolist.innertubex.sabr.ExperimentalSabrApi
import com.metrolist.innertubex.sabr.SabrAudioStream
import io.ktor.client.HttpClient
import java.io.EOFException
import java.io.IOException
import java.io.PipedInputStream
import java.io.PipedOutputStream
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

@androidx.annotation.OptIn(UnstableApi::class)
@OptIn(ExperimentalSabrApi::class)
internal fun youtubeDataSourceFactory(
    stream: ExtractedStream,
    http: HttpClient,
    scope: CoroutineScope,
    playbackPosition: () -> Long,
): DataSource.Factory {
    val headers =
        stream.headers.filterKeys {
            !it.equals("Range", ignoreCase = true) &&
                !it.equals("Accept-Encoding", ignoreCase = true)
        } + ("Accept-Encoding" to "identity")
    val factory = DefaultHttpDataSource.Factory().setDefaultRequestProperties(headers)
    return DataSource.Factory {
        when {
            stream.sabrBootstrap != null ->
                YouTubeSabrDataSource(scope, stream.contentLengthBytes) { startPosition ->
                    // Decoder byte probes can precede a running playback clock.
                    val clock = playbackPosition.takeIf { startPosition == 0L }
                    SabrAudioStream(http, stream.sabrBootstrap!!, playbackPositionMs = clock)
                        .bytes()
                }
            (stream.requireBoundedRange || stream.useRangeChunks) &&
                stream.contentLengthBytes != null ->
                YouTubeRangeDataSource(
                    factory,
                    stream.contentLengthBytes!!,
                    stream.rangeChunkSizeBytes,
                )
            else -> factory.createDataSource()
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
internal class YouTubeRangeDataSource(
    private val factory: HttpDataSource.Factory,
    private val contentLength: Long,
    chunkSize: Long,
) : BaseDataSource(true) {
    private val chunkSize = chunkSize.coerceIn(64 * 1024, 1024 * 1024)
    private var request: DataSpec? = null
    private var source: HttpDataSource? = null
    private var position = 0L
    private var remaining = 0L
    private var chunkRemaining = 0L

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        if (dataSpec.position > contentLength) {
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        request = dataSpec
        position = dataSpec.position
        remaining =
            (contentLength - position).let {
                if (dataSpec.length == C.LENGTH_UNSET.toLong()) it else minOf(it, dataSpec.length)
            }
        transferStarted(dataSpec)
        return if (dataSpec.length == C.LENGTH_UNSET.toLong()) remaining else dataSpec.length
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        if (chunkRemaining == 0L) {
            source?.close()
            val size = minOf(chunkSize, remaining)
            val spec =
                requireNotNull(request).buildUpon().setPosition(position).setLength(size).build()
            val next = factory.createDataSource()
            source = next
            next.open(spec)
            val range =
                next.responseHeaders.entries
                    .firstOrNull { it.key.equals("Content-Range", true) }
                    ?.value
                    ?.singleOrNull()
            if (
                next.responseCode != 206 ||
                    range != "bytes $position-${position + size - 1}/$contentLength"
            ) {
                throw IOException("Invalid media range response")
            }
            chunkRemaining = size
        }
        val count =
            requireNotNull(source)
                .read(buffer, offset, minOf(length.toLong(), chunkRemaining).toInt())
        if (count == C.RESULT_END_OF_INPUT) throw EOFException("Incomplete media range")
        position += count
        remaining -= count
        chunkRemaining -= count
        bytesTransferred(count)
        return count
    }

    override fun getUri(): Uri? = request?.uri

    override fun close() {
        try {
            source?.close()
        } finally {
            source = null
            if (request != null) transferEnded()
            request = null
            chunkRemaining = 0
        }
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
internal class YouTubeSabrDataSource(
    private val scope: CoroutineScope,
    private val contentLength: Long? = null,
    private val chunks: (Long) -> Flow<ByteArray>,
) : BaseDataSource(true) {
    private var request: DataSpec? = null
    private var input: PipedInputStream? = null
    private var output: PipedOutputStream? = null
    private var producer: Job? = null
    private var failure = AtomicReference<Throwable?>(null)
    private var remaining = C.LENGTH_UNSET.toLong()

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        if (contentLength != null && dataSpec.position > contentLength) {
            throw DataSourceException(PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE)
        }
        request = dataSpec
        if (contentLength != null && dataSpec.position == contentLength) {
            remaining = 0
            transferStarted(dataSpec)
            return if (dataSpec.length == C.LENGTH_UNSET.toLong()) 0 else dataSpec.length
        }
        val pipe = PipedInputStream(256 * 1024)
        val writer = PipedOutputStream(pipe)
        input = pipe
        output = writer
        remaining = contentLength ?: C.LENGTH_UNSET.toLong()
        val currentFailure = AtomicReference<Throwable?>(null)
        failure = currentFailure
        producer =
            scope
                .launch(Dispatchers.IO) {
                    try {
                        chunks(dataSpec.position).collect { writer.write(it) }
                    } catch (error: CancellationException) {
                        throw error
                    } catch (error: Exception) {
                        currentFailure.set(error)
                    }
                }
                .apply {
                    // The session can be cancelled before the producer starts.
                    invokeOnCompletion { runCatching { writer.close() } }
                }
        transferStarted(dataSpec)
        var skip = dataSpec.position
        val scratch = ByteArray(32 * 1024)
        while (skip > 0) {
            val count = read(scratch, 0, minOf(skip, scratch.size.toLong()).toInt())
            if (count == C.RESULT_END_OF_INPUT) {
                throw DataSourceException(
                    PlaybackException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE
                )
            }
            skip -= count
        }
        remaining =
            when {
                contentLength == null -> dataSpec.length
                dataSpec.length == C.LENGTH_UNSET.toLong() -> contentLength - dataSpec.position
                else -> minOf(contentLength - dataSpec.position, dataSpec.length)
            }
        return if (dataSpec.length == C.LENGTH_UNSET.toLong()) remaining else dataSpec.length
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining == 0L) return C.RESULT_END_OF_INPUT
        val requested =
            if (remaining == C.LENGTH_UNSET.toLong()) length
            else minOf(length.toLong(), remaining).toInt()
        val count = requireNotNull(input).read(buffer, offset, requested)
        if (count < 0) {
            if (failure.get() != null) throw IOException("YouTube Music stream failed")
            if (contentLength != null && remaining > 0 && producer?.isCancelled != true) {
                throw EOFException("Incomplete YouTube Music stream")
            }
            return C.RESULT_END_OF_INPUT
        }
        bytesTransferred(count)
        if (remaining != C.LENGTH_UNSET.toLong()) remaining -= count
        return count
    }

    override fun getUri(): Uri? = request?.uri

    override fun close() {
        producer?.cancel()
        producer = null
        runCatching { input?.close() }
        runCatching { output?.close() }
        input = null
        output = null
        if (request != null) transferEnded()
        request = null
        remaining = C.LENGTH_UNSET.toLong()
    }
}
