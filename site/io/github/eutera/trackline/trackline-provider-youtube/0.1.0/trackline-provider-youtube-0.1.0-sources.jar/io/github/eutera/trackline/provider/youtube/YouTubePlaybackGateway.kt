package io.github.eutera.trackline.provider.youtube

import com.metrolist.innertubex.extraction.ExtractedStream
import com.metrolist.innertubex.extraction.StreamResolveException
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.playback.PlaybackCommand
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import io.github.eutera.trackline.provider.api.playback.PlaybackSnapshot
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout

internal class YouTubePlaybackGateway(
    private val scope: CoroutineScope,
    private val resolve: suspend (String) -> ExtractedStream,
    private val engine: YouTubePlaybackEngine,
    private val trace: YouTubeTrace = YouTubeTrace(),
) : PlaybackGateway {
    override val selectionTimeoutMs = 30_000L

    private var listener: PlaybackGateway.Listener? = null
    private var selection: Job? = null
    private var generation = 0
    private var current: TrackRef? = null

    override fun connect(listener: PlaybackGateway.Listener) {
        disconnect()
        this.listener = listener
        trace.debug("playback connected")
        listener.onConnected()
    }

    override fun select(reference: TrackRef, completed: (PlaybackFailure?) -> Unit) {
        if (!YouTubeReferences.accepts(reference)) {
            reportFailure("select", PlaybackFailure.UPDATE_REQUIRED, completed)
            return
        }
        if (listener == null) {
            reportFailure("select", PlaybackFailure.DISCONNECTED, completed)
            return
        }
        selection?.cancel()
        engine.close()
        current = null
        val version = ++generation
        trace.debug("playback operation=select resolving stream")
        selection =
            scope.launch {
                try {
                    val stream = withTimeout(25_000) { resolve(reference.id) }
                    if (version != generation || listener == null) return@launch
                    if (stream.videoId != reference.id || stream.mediaMetadata?.isLive == true) {
                        reportFailure("select", PlaybackFailure.UPDATE_REQUIRED, completed)
                        return@launch
                    }
                    current = reference
                    trace.debug("playback stream resolved")
                    engine.play(
                        stream,
                        { paused, buffering ->
                            if (version == generation && current == reference) {
                                listener?.onPlayback(PlaybackSnapshot(paused, reference, buffering))
                            }
                        },
                        { failure -> if (version == generation) listener?.onFailure(failure) },
                    )
                    completed(null)
                } catch (_: TimeoutCancellationException) {
                    if (version == generation)
                        reportFailure("select", PlaybackFailure.TIMEOUT, completed)
                } catch (error: CancellationException) {
                    throw error
                } catch (error: Exception) {
                    if (version == generation)
                        reportFailure("select", error.playbackFailure(), completed)
                }
            }
    }

    override fun command(command: PlaybackCommand, completed: (PlaybackFailure?) -> Unit) {
        if (listener == null || (current == null && command == PlaybackCommand.PLAY)) {
            reportFailure(command.name, PlaybackFailure.DISCONNECTED, completed)
            return
        }
        when (command) {
            PlaybackCommand.PLAY -> engine.resume()
            PlaybackCommand.PAUSE -> if (current != null) engine.pause()
        }
        trace.debug("playback operation=${command.name} acknowledged")
        completed(null)
    }

    override fun disconnect() {
        if (listener != null) trace.debug("playback disconnected")
        ++generation
        listener = null
        selection?.cancel()
        selection = null
        current = null
        engine.close()
    }

    private fun reportFailure(
        operation: String,
        failure: PlaybackFailure,
        completed: (PlaybackFailure?) -> Unit,
    ) {
        trace.warning("playback operation=$operation failed code=${failure.name}")
        completed(failure)
    }
}

private fun Exception.playbackFailure(): PlaybackFailure =
    when (this) {
        is IOException -> PlaybackFailure.OFFLINE
        is StreamResolveException ->
            when (reason) {
                StreamResolveException.Reason.NETWORK -> PlaybackFailure.OFFLINE
                else -> PlaybackFailure.UNKNOWN
            }
        else -> PlaybackFailure.UNKNOWN
    }
