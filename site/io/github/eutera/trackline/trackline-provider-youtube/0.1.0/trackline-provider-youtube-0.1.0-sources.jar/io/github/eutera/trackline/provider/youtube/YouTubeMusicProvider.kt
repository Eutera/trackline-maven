package io.github.eutera.trackline.provider.youtube

import android.content.Context
import android.content.pm.ApplicationInfo
import android.util.Log
import io.github.eutera.trackline.provider.api.MusicCredits
import io.github.eutera.trackline.provider.api.MusicProvider
import io.github.eutera.trackline.provider.api.TrackRef
import io.github.eutera.trackline.provider.api.catalog.CatalogRepository
import io.github.eutera.trackline.provider.api.playback.PlaybackGateway
import kotlinx.coroutines.CoroutineScope

class YouTubeMusicProvider(context: Context) : MusicProvider {
    private val applicationContext = context.applicationContext

    override val id = YouTubeReferences.PROVIDER_ID
    override val displayName = "YouTube Music"
    override val musicCredits =
        MusicCredits(emptyList(), applicationContext.getString(R.string.youtube_music_credits))
    private val debug =
        applicationContext.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0
    private val trace = YouTubeTrace { priority, message ->
        if (debug || priority >= Log.WARN) Log.println(priority, "TracklineYouTube", message)
    }
    private val client by lazy { YouTubeMusicClient(trace = trace) }
    override val catalog: CatalogRepository by lazy {
        YouTubeCatalogRepository(trace) { browseId, continuation ->
            client.browse(browseId, continuation)
        }
    }

    override fun accepts(reference: TrackRef) = YouTubeReferences.accepts(reference)

    override fun createPlaybackGateway(scope: CoroutineScope): PlaybackGateway =
        YouTubePlaybackGateway(
            scope,
            client::stream,
            ExoYouTubePlaybackEngine(applicationContext, client.http, scope, trace),
            trace,
        )
}
