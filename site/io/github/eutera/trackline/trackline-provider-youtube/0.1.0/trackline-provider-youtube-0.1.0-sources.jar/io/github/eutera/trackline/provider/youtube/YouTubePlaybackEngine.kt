package io.github.eutera.trackline.provider.youtube

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.metrolist.innertubex.extraction.ExtractedStream
import io.github.eutera.trackline.provider.api.playback.PlaybackFailure
import io.ktor.client.HttpClient
import java.util.concurrent.atomic.AtomicLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

internal interface YouTubePlaybackEngine {
    fun play(
        stream: ExtractedStream,
        observation: (Boolean, Boolean) -> Unit,
        failed: (PlaybackFailure) -> Unit,
    )

    fun pause()

    fun resume()

    fun close()
}

@androidx.annotation.OptIn(UnstableApi::class)
internal class ExoYouTubePlaybackEngine(
    private val context: Context,
    private val http: HttpClient,
    private val scope: CoroutineScope,
    private val trace: YouTubeTrace = YouTubeTrace(),
) : YouTubePlaybackEngine {
    private var player: ExoPlayer? = null
    private var clock: Job? = null
    private val position = AtomicLong(0)

    override fun play(
        stream: ExtractedStream,
        observation: (Boolean, Boolean) -> Unit,
        failed: (PlaybackFailure) -> Unit,
    ) {
        close()
        position.set(0)
        val engine =
            ExoPlayer.Builder(context)
                .setMediaSourceFactory(
                    DefaultMediaSourceFactory(
                        youtubeDataSourceFactory(stream, http, scope, position::get)
                    )
                )
                .build()
        player = engine
        engine.setAudioAttributes(AudioAttributes.DEFAULT, true)
        engine.setHandleAudioBecomingNoisy(true)
        engine.addListener(
            object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) {
                    if (
                        this@ExoYouTubePlaybackEngine.player !== player ||
                            player.currentMediaItem?.mediaId != stream.videoId
                    ) {
                        return
                    }
                    observation(
                        !player.isPlaying,
                        player.playbackState == Player.STATE_BUFFERING ||
                            player.playbackState == Player.STATE_IDLE,
                    )
                }

                override fun onPlayerError(error: PlaybackException) {
                    if (player !== engine) return
                    trace.warning("playback engine failed code=${error.errorCodeName}")
                    failed(
                        when (error.errorCode) {
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                                PlaybackFailure.OFFLINE
                            else -> PlaybackFailure.UNKNOWN
                        }
                    )
                }
            }
        )
        val item =
            MediaItem.Builder()
                .setMediaId(stream.videoId)
                .setUri(stream.audioUrl)
                .setMimeType(stream.mimeType?.substringBefore(';'))
                .build()
        engine.setMediaItem(item)
        engine.prepare()
        engine.play()
        clock =
            scope.launch {
                while (player === engine) {
                    position.set(engine.currentPosition)
                    delay(250)
                }
            }
    }

    override fun pause() {
        player?.pause()
    }

    override fun resume() {
        player?.let {
            if (it.playbackState == Player.STATE_ENDED) it.seekTo(0)
            it.play()
        }
    }

    override fun close() {
        clock?.cancel()
        clock = null
        val previous = player
        player = null
        previous?.release()
    }
}
